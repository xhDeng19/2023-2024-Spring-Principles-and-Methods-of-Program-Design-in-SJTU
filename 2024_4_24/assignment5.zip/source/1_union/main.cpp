# include <iostream>

using namespace std;

const int N=100;
enum Operation {AddL, AddR, SubL, SubR, Assign, Var, Jmp, JmpEq, JmpGt, JmpLt, Const, Print, Halt};
struct Command{
    Operation type; 
    union { 
        int i; 
        double d; 
        char ch; 
    } value; 
}cmd[N];


int main()
{
    // Todo: First read all the commands into cmd[N];
    // Then use pc as a subscript in cmd.

    return 0;
}