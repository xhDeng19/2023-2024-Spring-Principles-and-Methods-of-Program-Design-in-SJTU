#include <iostream>

const size_t MAX_SIZE = 102;

int main()
{
    int model[MAX_SIZE][MAX_SIZE] = {}; // 初始化二维数组为全0
    int n, m;
    std::cin >> n >> m;

    return 0;
}
