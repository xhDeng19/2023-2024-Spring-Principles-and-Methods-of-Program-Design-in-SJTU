
// match : 检查text中是否存在子串匹配regexp描述的格式
bool match(char *regexp, char *text);

// matchstart : 检查text的开头子串是否匹配regexp
bool matchstart(char *regexp, char *text);

// matchstar : 检查text的开头子串是否匹配表达式 c*regexp
bool matchstar(int c, char *regexp, char *text);

int main(){
    return 0;
}